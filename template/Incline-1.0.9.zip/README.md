# Instructions

Please open `dist/documentation.html` to get started.